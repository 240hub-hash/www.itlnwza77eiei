const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const STORE = path.join(ROOT, "s");
const PORT = process.env.PORT || 3000;

if (!fs.existsSync(STORE)) fs.mkdirSync(STORE, { recursive: true });

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
};

// Static files this app serves
function serveStatic(res, urlPath) {
  const map = {
    "/": "index.html",
    "/index.html": "index.html",
    "/styles.css": "styles.css",
    "/app.js": "app.js",
  };
  const file = map[urlPath];
  if (!file) return false;
  const p = path.join(ROOT, file);
  if (!fs.existsSync(p)) return false;
  res.writeHead(200, { "content-type": MIME[path.extname(p)] || "application/octet-stream" });
  res.end(fs.readFileSync(p));
  return true;
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function seg(len) {
  let s = "";
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  for (let i = 0; i < len; i++) s += chars[(Math.random() * 36) | 0];
  return s;
}
function randomId() {
  return `by240-${seg(2)}-${seg(2)}-${seg(3)}`;
}

function isImageLink(l) {
  return /\.(png|jpe?g|gif|webp|bmp|avif|svg|ico)(\?.*)?(#.*)?$/i.test(l);
}
function isVideoLink(l) {
  return /\.(mp4|webm|ogg|mov|ogv|m4v)(\?.*)?(#.*)?$/i.test(l);
}

const MEDIA_PAGE = (el, isVideo) => `<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"><title>BY240</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,900&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;
font-family:"Segoe UI",system-ui,sans-serif;background:#0a0a0a;color:#f5f5f5;padding:20px}
img,video{max-width:100%;max-height:60vh;width:auto;height:auto;object-fit:contain;border-radius:8px;
box-shadow:0 18px 50px rgba(0,0,0,.8);border:1px solid #222;background:#000}
img{width:100%;max-width:460px}
.vid-block{display:flex;flex-direction:column;align-items:center;gap:14px}
.vid-block video{display:block;cursor:pointer}
.tap-hint{font-size:14px;font-weight:600;letter-spacing:.5px;color:#d0d0d0;
background:rgba(20,20,20,.7);border:1px solid #333;padding:10px 22px;border-radius:999px;cursor:pointer}
.tap-hint:hover{background:#2a2a2a;color:#fff}
.mark{font-size:140px;font-weight:900;font-style:italic;font-family:"Playfair Display",Georgia,serif;letter-spacing:4px;
color:transparent;background-clip:text;-webkit-background-clip:text;background-image:linear-gradient(180deg,#ffffff,#5a5a5a);
filter:drop-shadow(0 12px 30px rgba(0,0,0,.7))}
@media(max-width:480px){body{padding:16px}img{max-width:300px}.mark{font-size:90px}}
</style></head><body><div class="mark">by240</div>
${el}${isVideo ? `<script>
const v=document.getElementById("vd");const hint=document.getElementById("tapHint");
function play(){v.muted=false;v.volume=1;hint.textContent="กำลังเล่น...";
v.play().then(()=>{hint.style.display="none";}).catch(()=>{hint.textContent="แตะเพื่อเล่นเสียง";});}
[v,hint].forEach(el=>el.addEventListener("click",play));</script>` : ""}</body></html>`;

const YT_PAGE = (embed) => `<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"><title>BY240</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,900&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:24px;
font-family:"Segoe UI",system-ui,sans-serif;background:#0a0a0a;color:#f5f5f5;padding:20px}
.mark{font-size:150px;font-weight:900;font-style:italic;font-family:"Playfair Display",Georgia,serif;letter-spacing:4px;
color:transparent;background-clip:text;-webkit-background-clip:text;background-image:linear-gradient(180deg,#ffffff,#5a5a5a);
filter:drop-shadow(0 12px 30px rgba(0,0,0,.7))}
.vid{width:min(560px,90vw);aspect-ratio:16/9;border-radius:8px;overflow:hidden;
border:1px solid #222;box-shadow:0 18px 50px rgba(0,0,0,.8);background:#000}
iframe{width:100%;height:100%;border:0}
@media(max-width:480px){.mark{font-size:90px}}
</style></head><body><div class="mark">by240</div>
<div class="vid"><iframe src="${embed}" allow="autoplay; encrypted-media; fullscreen" allowfullscreen></iframe></div></body></html>`;

const DEFAULT_LINK = "https://cdn.discordapp.com/attachments/1534204097404866560/1545051390664249456/Messenger_creation_227D07DD-E7B3-4086-A0E6-1A82A583206F.mp4?ex=6aa2a5bd&is=6aa1543d&hm=e0e8af6aa01fa860dd8fe3d865fc21a094ea16b6da73e15a9498e77bb7aa5860&";

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  const p = url.pathname;

  if (req.method === "POST" && p === "/shorten") {
    let body;
    try {
      body = JSON.parse(await readBody(req));
    } catch {
      return json(res, 400, { error: "ข้อมูลไม่ถูกต้อง" });
    }
    const code = typeof body.code === "string" ? body.code.trim() : "";
    const link = typeof body.link === "string" ? body.link.trim() : "";
    if (!code) return json(res, 400, { error: "กรุณาใส่โค้ด Lua" });
    if (code.length > 80000) return json(res, 400, { error: "โค้ดยาวเกินไป (จำกัด 80,000 ตัวอักษร)" });

    let id;
    do {
      id = randomId();
    } while (fs.existsSync(path.join(STORE, id + ".lua")));

    // Store the REAL Lua code as a file on your own server
    fs.writeFileSync(path.join(STORE, id + ".lua"), code, "utf8");
    fs.writeFileSync(path.join(STORE, id + ".link"), link, "utf8");
    return json(res, 200, { id });
  }

  if (req.method === "GET" && p.startsWith("/s/")) {
    const id = decodeURIComponent(p.slice(3)).replace(/^\/+|\/+$/g, "");
    const codeFile = path.join(STORE, id + ".lua");
    if (!/^by240-[a-z0-9]{2}-[a-z0-9]{2}-[a-z0-9]{3}$/.test(id) || !fs.existsSync(codeFile)) {
      return text(res, 404, "Not found");
    }
    const code = fs.readFileSync(codeFile, "utf8");
    const linkFile = path.join(STORE, id + ".link");
    const storedLink = fs.existsSync(linkFile) ? fs.readFileSync(linkFile, "utf8").trim() : "";

    const ua = (req.headers["user-agent"] || "").toLowerCase();
    const execToken = /roblox|luau| executor|executor|synapse|fluxus|hydra|krnl|arceus|nightx|hydrogen|\bcodex\b|jjsploit|\basura\b|del|delta|gamehttp|httpget|gamesense|script\b/.test(ua);
    const browserToken = /\bmozilla\b|applewebkit|gecko\/|trident/.test(ua);
    const isBrowser = browserToken && !execToken;

    if (isBrowser) {
      const target = storedLink || DEFAULT_LINK;
      const isVideo = isVideoLink(target);
      const isImage = isImageLink(target);
      if (isVideo || isImage) {
        const el = isVideo
          ? `<div class="vid-block"><video id="vd" src="${esc(target)}" playsinline loop preload="auto"></video><div id="tapHint" class="tap-hint">แตะเพื่อเล่นเสียง</div></div>`
          : `<img src="${esc(target)}" alt="BY240">`;
        return html(res, 200, MEDIA_PAGE(el, isVideo));
      }
      const yt = target.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
      if (yt) {
        return html(res, 200, YT_PAGE(`https://www.youtube.com/embed/${yt[1]}?autoplay=1&rel=0`));
      }
      return html(res, 200, `<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><meta http-equiv="refresh" content="0;url=${esc(target)}"><title>Redirecting</title></head><body><script>location.replace(${JSON.stringify(target)});</script></body></html>`);
    }

    return text(res, 200, code);
  }

  if (serveStatic(res, p)) return;
  return text(res, 404, "Not found");
});

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}
function json(res, status, obj) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}
function text(res, status, s) {
  res.writeHead(status, { "content-type": "text/plain; charset=utf-8" });
  res.end(s);
}
function html(res, status, s) {
  res.writeHead(status, { "content-type": "text/html; charset=utf-8" });
  res.end(s);
}

server.listen(PORT, () => {
  console.log(`Lua Short running on http://localhost:${PORT}`);
});