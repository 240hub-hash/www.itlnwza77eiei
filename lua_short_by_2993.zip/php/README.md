# Lua Short (PHP) — เก็บโค้ดสคริปต์เป็นไฟล์จริง

เว็บย่อสคริปต์ Lua แบบ self-host **แต่ละสคริปต์ที่ย่อ = 1 ไฟล์** ในโฟลเดอร์ `s/`
ทำงานบนโฮสติ้ง PHP (shared hosting / cPanel) ราคาถูก ไม่พึ่ง websim.com ไม่มีลายน้ำ

- ตัวรัน: `loadstring(game:HttpGet('https://<เว็บคุณ>/s/<id>'))()` → ได้โค้ด Lua จริง
- เบราว์เซอร์: เห็นหน้า `by240` + ลิงก์ที่ตั้งไว้ (YouTube / รูป / วิดีโอ / redirect)

## ไฟล์ทั้งหมด

```
index.php      ← หน้าย่อสคริปต์
shorten.php    ← รับโค้ด → สร้างไฟล์ s/<id>.lua (โค้ดจริง) + s/<id>.link (ลิงก์)
s.php          ← ตัวรันได้โค้ดจริง / เบราว์เซอร์เห็นหน้า by240
shorten.js     ← ตรรกะ client (ใช้ location.origin — ไม่ผูกโดเมน)
styles.css     ← สไตล์
.htaccess      ← ให้ /s/<id> พังลงสวย ๆ (Apache)
s/             ← โฟลเดอร์เก็บไฟล์ .lua ของทุกสคริปต์ (สร้างอัตโนมัติ)
.gitignore
```

### แฟ้มแต่ละสคริปต์ (ชื่อเฉพาะของมันเอง)
เมื่อกดย่อ จะสร้างไฟล์ 2 ไฟล์ใน `s/`:

| ไฟล์ | เก็บอะไร |
|------|---------|
| `s/by240-xx-yy-zzz.lua` | **โค้ด Lua จริง** ที่ตัวรันดึงไป |
| `s/by240-xx-yy-zzz.link` | ลิงก์หน้าเบราว์เซอร์ |

## เอาไปลง GitHub
```bash
cd php
git init && git add . && git commit -m "Lua Short PHP"
git branch -M main
git remote add origin https://github.com/<you>/lua-short.git
git push -u origin main
```

## เอาไปบนโฮสต์ PHP (ใช้งานจริง)
1. copy ไฟล์ทั้งหมด (ยกเว้น `s/.gitkeep`) ไปที่โฟลเดอร์เว็บ เช่น `public_html/`
2. ตรวจว่าโฟลเดอร์ `s/` เขียนไฟล์ได้ (chmod `0755` หรือผ่าน cPanel)
3. เปิด `https://โดเมนคุณ/index.php` ย่อได้เลย

ต้องเป็นโฮสต์ **Apache + PHP + เขียนไฟล์ได้** (cPanel shared hosting, cPanel VPS)
`.htaccess` มีผลเมื่อ Apache เปิด `mod_rewrite`
ถ้าโฮสต์ไม่รองรับ rewrite ให้เปลี่ยน URL ตัวรันเป็น `https://โดเมนคุณ/s.php?id=<id>`

## ตัวรันใช้ลิงก์
โค้ดจากช่องผลลัพธ์ (เช่น):
```
loadstring(game:HttpGet('https://lua-short.com/s/by240-a1-b2-c3d'))()
```
executor เกม → GET URL นั้น → ได้โค้ด Lua จริง → loadstring + รัน